
CREATE DATABASE IF NOT EXISTS food_rescue;
USE food_rescue;

CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100),
    email VARCHAR(100) UNIQUE,
    password VARCHAR(255),
    role ENUM('restaurant', 'ngo', 'volunteer', 'admin') DEFAULT 'ngo'
);
