const express = require('express');
const router = express.Router();

router.get('/', (req, res) => res.render('index'));
router.get('/login', (req, res) => res.render('login'));
router.get('/signup', (req, res) => res.render('signup'));

router.post('/signup', (req, res) => {
    const { name, email, password, role } = req.body;
    const db = req.app.locals.db;
    db.query('INSERT INTO users (name, email, password, role) VALUES (?, ?, ?, ?)', [name, email, password, role], err => {
        if (err) throw err;
        res.redirect('/login');
    });
});

router.post('/login', (req, res) => {
    const { email, password } = req.body;
    const db = req.app.locals.db;
    db.query('SELECT * FROM users WHERE email = ? AND password = ?', [email, password], (err, results) => {
        if (err) throw err;
        if (results.length > 0) {
            req.session.user = results[0];
            res.redirect('/dashboard');
        } else {
            res.send('Invalid credentials');
        }
    });
});

module.exports = router;
